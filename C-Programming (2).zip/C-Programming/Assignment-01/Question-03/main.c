#include <stdio.h>

int main() {
    long long total, x, y;
    scanf("%lld %lld %lld", &total, &x, &y);

    long long longBen = total * x / 100;             /* Long Ben's x% */
    long long remaining = total - longBen;
    long long blackbeard = remaining * y / 100;      /* y% of the remainder */
    long long others = (remaining - blackbeard) / 3; /* 3 other pirates, equal share; leftovers thrown away */

    printf("%lld\n%lld\n%lld\n", longBen, blackbeard, others);
    return 0;
}
