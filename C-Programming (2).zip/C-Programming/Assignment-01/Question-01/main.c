#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

int main() {
    int distance = 0, member = 0, gotDistance = 0;
    char t[64];

    /* Works with "15 true" as well as "Distance: 15 / Member: true" */
    while (scanf("%63s", t) == 1) {
        if (isdigit((unsigned char)t[0])) {
            if (!gotDistance) { distance = atoi(t); gotDistance = 1; }
            else member = atoi(t) != 0;
        } else if (tolower((unsigned char)t[0]) == 't') {
            member = 1;
        }
    }

    double fare = 100;
    if (distance > 10)
        fare += (distance - 10) * 20;
    if (member)
        fare *= 0.9;

    long paise = lround(fare * 100);
    if (paise % 100 == 0)
        printf("Final Fare: ₹%ld\n", paise / 100);
    else
        printf("Final Fare: ₹%.2f\n", fare);
    return 0;
}
