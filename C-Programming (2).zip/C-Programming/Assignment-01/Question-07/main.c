#include <stdio.h>

int main() {
    int p, r, n;
    scanf("%d %d %d", &p, &r, &n);

    double interest = (double)p * r * n / 100.0;
    double amount = p + interest;
    double discount = interest * 0.02;
    double settlement = amount - discount;

    printf("%.2f\n%.2f\n%.2f\n%.2f\n", interest, amount, discount, settlement);
    return 0;
}
