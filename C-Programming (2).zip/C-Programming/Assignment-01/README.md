C Programming - Assignment 01

Name: Keshav
Register Number: 1925260042
SLOT : D
