#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main() {
    int v[2] = {0, 0}, n = 0;
    char t[64];

    /* Works with "9 88" as well as "Experience: 9 / Performance: 88" */
    while (n < 2 && scanf("%63s", t) == 1) {
        if (isdigit((unsigned char)t[0]) || t[0] == '-')
            v[n++] = atoi(t);
    }
    int exp = v[0], perf = v[1];

    const char *level;
    if (exp < 3)
        level = "Junior";
    else if (exp <= 7)
        level = (perf >= 80) ? "Mid-Level" : "Junior";
    else if (perf >= 85)
        level = "Senior";
    else
        level = (perf >= 80) ? "Mid-Level" : "Junior";

    printf("Level: %s\n", level);
    return 0;
}
