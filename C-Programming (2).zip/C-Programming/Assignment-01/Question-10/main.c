#include <stdio.h>
#include <math.h>

int main() {
    int units;
    scanf("%d", &units);

    double bill;
    if (units <= 200)
        bill = units * 0.50;
    else if (units <= 400)
        bill = units * 0.65 + 100;
    else if (units <= 600)
        bill = units * 0.80 + 200;
    else
        bill = units * 1.25 + 425;

    long paise = lround(bill * 100);
    if (paise % 100 == 0)
        printf("Rs.%ld\n", paise / 100);
    else
        printf("Rs.%.2f\n", bill);
    return 0;
}
